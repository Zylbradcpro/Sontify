-- Sontify backend foundation (Supabase/PostgreSQL).
-- Apply only after creating a Supabase project. Keep service-role keys server-side.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text not null default 'Sontify listener',
  bio text not null default '',
  avatar_url text,
  listening_activity_visible boolean not null default false,
  explicit_filter_enabled boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.artists (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid references auth.users(id) on delete set null,
  artist_name text not null,
  bio text not null default '',
  verified boolean not null default false,
  application_status text not null default 'not_applied'
    check (application_status in ('not_applied','pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.albums (
  id uuid primary key default gen_random_uuid(),
  artist_id uuid references public.artists(id) on delete set null,
  title text not null,
  artwork_url text,
  release_date date,
  created_at timestamptz not null default now()
);

create table if not exists public.songs (
  id uuid primary key default gen_random_uuid(),
  album_id uuid references public.albums(id) on delete set null,
  artist_id uuid references public.artists(id) on delete set null,
  title text not null,
  audio_url text,
  duration_ms bigint,
  playable boolean not null default false,
  rights_status text not null default 'pending'
    check (rights_status in ('pending','approved','restricted','rejected')),
  license_reference text,
  created_at timestamptz not null default now(),
  check (playable = false or (audio_url is not null and rights_status = 'approved'))
);

create table if not exists public.playlists (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  is_public boolean not null default false,
  collaborative boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.playlist_songs (
  playlist_id uuid not null references public.playlists(id) on delete cascade,
  song_id uuid not null references public.songs(id) on delete cascade,
  position integer not null default 0,
  added_at timestamptz not null default now(),
  primary key (playlist_id, song_id)
);

create table if not exists public.user_likes (
  user_id uuid not null references auth.users(id) on delete cascade,
  song_id uuid not null references public.songs(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, song_id)
);

create table if not exists public.follows (
  follower_id uuid not null references auth.users(id) on delete cascade,
  followed_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, followed_id),
  check (follower_id <> followed_id)
);

alter table public.profiles enable row level security;
alter table public.artists enable row level security;
alter table public.albums enable row level security;
alter table public.songs enable row level security;
alter table public.playlists enable row level security;
alter table public.playlist_songs enable row level security;
alter table public.user_likes enable row level security;
alter table public.follows enable row level security;

create policy "Profiles are publicly readable"
on public.profiles for select using (true);
create policy "Users create own profile"
on public.profiles for insert with check (auth.uid() = id);
create policy "Users update own profile"
on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

create policy "Approved artist records are visible"
on public.artists for select using (verified = true or owner_user_id = auth.uid());
create policy "Users submit artist applications"
on public.artists for insert with check (owner_user_id = auth.uid());

create policy "Approved songs are visible"
on public.songs for select using (playable = true and rights_status = 'approved');
create policy "Approved albums are visible"
on public.albums for select using (
  exists (select 1 from public.artists a where a.id = artist_id and a.verified = true)
);

create policy "Public playlists and own playlists visible"
on public.playlists for select using (is_public = true or owner_user_id = auth.uid());
create policy "Owners manage playlists"
on public.playlists for all using (owner_user_id = auth.uid()) with check (owner_user_id = auth.uid());

create policy "Playlist songs visible through visible playlists"
on public.playlist_songs for select using (
  exists (select 1 from public.playlists p where p.id = playlist_id
    and (p.is_public = true or p.owner_user_id = auth.uid()))
);
create policy "Playlist owners manage playlist songs"
on public.playlist_songs for all using (
  exists (select 1 from public.playlists p where p.id = playlist_id and p.owner_user_id = auth.uid())
) with check (
  exists (select 1 from public.playlists p where p.id = playlist_id and p.owner_user_id = auth.uid())
);

create policy "Users manage own likes"
on public.user_likes for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "Users manage own follows"
on public.follows for all using (follower_id = auth.uid()) with check (follower_id = auth.uid());
