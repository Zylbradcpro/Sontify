package com.sontify.app

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay

private val Black = Color(0xFF000000)
private val Panel = Color(0xFF171717)
private val Panel2 = Color(0xFF242424)
private val White = Color(0xFFFFFFFF)
private val Muted = Color(0xFF9A9A9A)

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val uri: Uri,
    val duration: Long
)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            SontifyApp(
                context = this,
                player = player,
                onLoadTracks = { loadDeviceTracks() }
            )
        }
    }

    private fun loadDeviceTracks(): List<Track> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val result = mutableListOf<Track>()
        val cursor: Cursor? = contentResolver.query(
            collection, projection, selection, null, sortOrder
        )
        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (it.moveToNext()) {
                val id = it.getLong(idCol)
                val title = it.getString(titleCol) ?: "Unknown title"
                val artist = it.getString(artistCol) ?: "Unknown artist"
                val duration = it.getLong(durationCol)
                val uri = ContentUris.withAppendedId(collection, id)
                result.add(Track(id, title, artist, uri, duration))
            }
        }
        return result
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}

@Composable
private fun SontifyApp(
    context: Context,
    player: ExoPlayer,
    onLoadTracks: () -> List<Track>
) {
    var tab by remember { mutableStateOf("Home") }
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var current by remember { mutableStateOf<Track?>(null) }
    var query by remember { mutableStateOf("") }
    var permissionGranted by remember { mutableStateOf(hasAudioPermission(context)) }
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var favorites by remember { mutableStateOf(loadFavorites(context)) }
    var showCreatePlaylist by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }
    var playlists by remember { mutableStateOf(loadPlaylists(context)) }
    var message by remember { mutableStateOf<String?>(null) }

    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
        if (granted) tracks = onLoadTracks()
        else message = "Sontify needs audio access to find music stored on this phone."
    }

    LaunchedEffect(permissionGranted) {
        if (permissionGranted) tracks = onLoadTracks()
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                duration = player.duration.coerceAtLeast(0L)
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(current, isPlaying) {
        while (isPlaying) {
            position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.coerceAtLeast(0L)
            delay(500)
        }
    }

    fun play(track: Track) {
        current = track
        player.setMediaItem(MediaItem.fromUri(track.uri))
        player.prepare()
        player.play()
    }

    val visibleTracks = when (tab) {
        "Search" -> tracks.filter {
            it.title.contains(query, true) || it.artist.contains(query, true)
        }
        "Library" -> tracks.filter { favorites.contains(it.id) }
        else -> tracks
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = White,
            onPrimary = Black,
            background = Black,
            surface = Panel,
            onSurface = White,
            secondary = Muted
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Black) {
            Column(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier.weight(1f).fillMaxWidth()
                        .padding(horizontal = 18.dp)
                ) {
                    when (tab) {
                        "Home" -> HomeScreen(
                            tracks = tracks,
                            permissionGranted = permissionGranted,
                            onRequestPermission = { permissionLauncher.launch(permission) },
                            onPlay = ::play,
                            onGoSearch = { tab = "Search" }
                        )
                        "Search" -> SearchScreen(
                            query = query,
                            onQuery = { query = it },
                            tracks = visibleTracks,
                            onPlay = ::play
                        )
                        "Library" -> LibraryScreen(
                            tracks = visibleTracks,
                            playlists = playlists,
                            onPlay = ::play,
                            onCreatePlaylist = { showCreatePlaylist = true }
                        )
                        "Friends" -> SimpleInfoScreen(
                            title = "Friends",
                            description = "Friend profiles and shared listening will be added when Sontify accounts and its secure backend are connected."
                        )
                        else -> ProfileScreen()
                    }
                }

                if (current != null) {
                    MiniPlayer(
                        track = current!!,
                        playing = isPlaying,
                        position = position,
                        duration = duration,
                        onPlayPause = {
                            if (player.isPlaying) player.pause() else player.play()
                        },
                        onClose = {
                            player.stop()
                            current = null
                            position = 0L
                        }
                    )
                }

                NavigationBar(containerColor = Black, contentColor = White) {
                    val items = listOf(
                        Triple("Home", Icons.Filled.Home, "Home"),
                        Triple("Search", Icons.Filled.Search, "Search"),
                        Triple("Library", Icons.Filled.LibraryMusic, "Library"),
                        Triple("Friends", Icons.Filled.People, "Friends"),
                        Triple("Profile", Icons.Filled.Person, "Profile")
                    )
                    items.forEach { (label, icon, route) ->
                        NavigationBarItem(
                            selected = tab == route,
                            onClick = { tab = route },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = White,
                                selectedTextColor = White,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted,
                                indicatorColor = Panel2
                            )
                        )
                    }
                }
            }
        }

        if (showCreatePlaylist) {
            AlertDialog(
                onDismissRequest = { showCreatePlaylist = false },
                title = { Text("New playlist", color = White) },
                text = {
                    OutlinedTextField(
                        value = playlistName,
                        onValueChange = { playlistName = it },
                        label = { Text("Playlist name") },
                        singleLine = true
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val name = playlistName.trim()
                        if (name.isNotEmpty()) {
                            playlists = playlists + name
                            savePlaylists(context, playlists)
                        }
                        playlistName = ""
                        showCreatePlaylist = false
                    }) { Text("Create") }
                },
                dismissButton = {
                    TextButton(onClick = { showCreatePlaylist = false }) { Text("Cancel") }
                },
                containerColor = Panel
            )
        }

        message?.let {
            AlertDialog(
                onDismissRequest = { message = null },
                confirmButton = {
                    TextButton(onClick = { message = null }) { Text("OK") }
                },
                text = { Text(it, color = White) },
                containerColor = Panel
            )
        }
    }
}

@Composable
private fun HomeScreen(
    tracks: List<Track>,
    permissionGranted: Boolean,
    onRequestPermission: () -> Unit,
    onPlay: (Track) -> Unit,
    onGoSearch: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Spacer(Modifier.height(22.dp))
        Text("SONTIFY", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        Text("Listen. Discover. Enjoy.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(26.dp))
        Text("Your music starts here.", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "A music home built around what you love.",
            color = Muted,
            fontSize = 14.sp
        )
        Spacer(Modifier.height(20.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("YOUR MUSIC", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                Text("Play music stored on your phone", color = White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "This first build plays local audio files. Online licensed streaming will be connected separately.",
                    color = Muted,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onRequestPermission,
                    colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black)
                ) {
                    Text(if (permissionGranted) "Refresh music library" else "Find music on this phone")
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Recently added", color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onGoSearch) { Text("Search", color = Muted) }
        }
        if (tracks.isEmpty()) {
            Text(
                "No local music found yet. Allow audio access and make sure this phone has audio files.",
                color = Muted,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(tracks.take(8), key = { it.id }) { track ->
                    TrackRow(track = track, onClick = { onPlay(track) }, trailing = null)
                }
            }
        }
    }
}

@Composable
private fun SearchScreen(
    query: String,
    onQuery: (String) -> Unit,
    tracks: List<Track>,
    onPlay: (Track) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(24.dp))
        Text("Search", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Songs or artists on this phone") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = White,
                unfocusedTextColor = White,
                focusedBorderColor = White,
                unfocusedBorderColor = Panel2,
                cursorColor = White
            )
        )
        Spacer(Modifier.height(18.dp))
        Text("LOCAL RESULTS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        LazyColumn {
            items(tracks, key = { it.id }) { track ->
                TrackRow(track = track, onClick = { onPlay(track) }, trailing = null)
            }
        }
    }
}

@Composable
private fun LibraryScreen(
    tracks: List<Track>,
    playlists: List<String>,
    onPlay: (Track) -> Unit,
    onCreatePlaylist: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(24.dp))
        Text("Your Library", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = onCreatePlaylist,
            colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black)
        ) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("Create playlist")
        }
        if (playlists.isNotEmpty()) {
            Spacer(Modifier.height(18.dp))
            Text("PLAYLISTS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
            playlists.forEach {
                Text(it, color = White, modifier = Modifier.padding(vertical = 8.dp))
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("LIKED SONGS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        if (tracks.isEmpty()) {
            Text("Songs you like will appear here.", color = Muted, modifier = Modifier.padding(top = 10.dp))
        } else {
            LazyColumn {
                items(tracks, key = { it.id }) { track ->
                    TrackRow(track = track, onClick = { onPlay(track) }, trailing = null)
                }
            }
        }
    }
}

@Composable
private fun TrackRow(
    track: Track,
    onClick: () -> Unit,
    trailing: (@Composable () -> Unit)?
) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).background(Panel2, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Muted)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = White, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing?.invoke()
        Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = Muted)
    }
}

@Composable
private fun MiniPlayer(
    track: Track,
    playing: Boolean,
    position: Long,
    duration: Long,
    onPlayPause: () -> Unit,
    onClose: () -> Unit
) {
    Column(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.MusicNote, contentDescription = null, tint = White, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, color = Muted, fontSize = 11.sp, maxLines = 1)
            }
            IconButton(onClick = onPlayPause) {
                Icon(
                    if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (playing) "Pause" else "Play",
                    tint = White
                )
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Stop", tint = Muted)
            }
        }
        LinearProgressIndicator(
            progress = { if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f },
            modifier = Modifier.fillMaxWidth().height(2.dp),
            color = White,
            trackColor = Panel2
        )
    }
}

@Composable
private fun ProfileScreen() {
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(24.dp))
        Text("Profile", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Text("Sontify listener", color = White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text("Local device profile", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        Text("ACCOUNT FEATURES", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "Online sign-in, synced profiles, subscriptions, artist tools, and family accounts need a secure backend and service connections. They are not activated in this offline-first foundation.",
            color = Muted,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun SimpleInfoScreen(title: String, description: String) {
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(24.dp))
        Text(title, color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(description, color = Muted, fontSize = 14.sp)
    }
}

private fun hasAudioPermission(context: Context): Boolean {
    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}

private fun loadFavorites(context: Context): Set<Long> {
    return context.getSharedPreferences("sontify", Context.MODE_PRIVATE)
        .getStringSet("favorites", emptySet())
        ?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet()
}

private fun saveFavorites(context: Context, favorites: Set<Long>) {
    context.getSharedPreferences("sontify", Context.MODE_PRIVATE)
        .edit().putStringSet("favorites", favorites.map { it.toString() }.toSet()).apply()
}

private fun loadPlaylists(context: Context): List<String> {
    return context.getSharedPreferences("sontify", Context.MODE_PRIVATE)
        .getStringSet("playlists", emptySet())?.toList()?.sorted() ?: emptyList()
}

private fun savePlaylists(context: Context, playlists: List<String>) {
    context.getSharedPreferences("sontify", Context.MODE_PRIVATE)
        .edit().putStringSet("playlists", playlists.toSet()).apply()
}
